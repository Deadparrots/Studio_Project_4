﻿using System;

[Serializable]
public class NetStats
{
    public int averagePing = 0;
    public int lastPing = 0;
}
